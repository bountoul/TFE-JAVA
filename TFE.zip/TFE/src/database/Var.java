package database;

public class Var {
	
	
	//For new users
	public static String newName;
	public static String newFirstName;
	
	//For connection to Database
	public static String user;
	public static String password;
	
	//For Client
	public static int idClient;
	
}
